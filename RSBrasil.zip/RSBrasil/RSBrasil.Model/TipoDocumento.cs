﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RSBrasil.Model
{
    public class TipoDocumento
    {
        public string Descricao { get; set; }
        public int? Documentos_IdDocumentos { get; set; }
        public int? IdTipoDocumento { get; set; }
    }
}
